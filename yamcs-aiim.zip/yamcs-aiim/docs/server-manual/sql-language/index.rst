SQL Language
============

This appendix specifies the SQL language used by Yamcs for its internal database.

.. toctree::
    :maxdepth: 1
    :caption: Table of Contents

    identifiers
    literals
    operators
    object-names
    expressions
    functions
    statements
