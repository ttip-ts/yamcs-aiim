Identifiers
===========

.. container:: productionlist

   .. productionlist:: sql-grammar
      identifier: `letter`+ ( `digit` | `letter` | `specialchars` )*
      letter: "A"..."Z"
      specialchars: "$" | "_" | "# | "."
