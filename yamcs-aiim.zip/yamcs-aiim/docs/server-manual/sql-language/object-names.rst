Object Names
============

.. container:: productionlist

   .. productionlist:: sql-grammar
      objectName: `identifier` | `doubleQuotedIdentifier`
      doubleQuotedIdentifier: '"' `stringchar`* '"'
