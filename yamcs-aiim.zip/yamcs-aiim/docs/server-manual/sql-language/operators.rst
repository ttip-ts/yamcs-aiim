Operators
=========

.. container:: productionlist

   .. productionlist:: sql-grammar
      addOp: "+" | "-" | "||"
      multOp: "*" | "/" | "MOD"
      relOp: "=" | "!=" | ">=" | ">" | "<>" | "<=" | "&&" | "<"
      bitWiseOp: "&" | "|" | "^" | "<<" | ">>"
