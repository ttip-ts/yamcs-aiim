Parameter Definitions
=====================


