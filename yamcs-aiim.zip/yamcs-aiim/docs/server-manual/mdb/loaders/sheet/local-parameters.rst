Local Parameters Sheet
======================

This sheet contains information for parameters that are local to Yamcs and that can be set by users.

The structure of this sheet is identical to the :doc:`Parameters sheet <parameters>`.
