Derived Parameters Sheet
========================

This sheet contains information for parameters that are the results of algorithm computations.

The structure of this sheet is identical to the :doc:`Parameters sheet <parameters>`.
