The value must be understandable for the used engineering type.

For binary, use a hexadecimal notation.

For booleans, use a value of ``true`` or ``false``.

For arrays, specify a value in JSON format: ``[-3, -2.4, 5]``.

For aggregates, specify a value in JSON format: ``{member1: 1, member2: 2}``.
