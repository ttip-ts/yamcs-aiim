Alarms
======

Shows an overview of the current alarms. Alarms indicate parameters that are out of limits.
