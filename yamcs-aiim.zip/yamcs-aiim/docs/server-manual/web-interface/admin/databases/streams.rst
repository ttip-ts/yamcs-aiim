Streams
=======

This page lists all the streams in a specific Yamcs database.

For each stream we can see a description of its columns. We can also snoop on newly emitted tuples.

For more information on the standard streams, see :doc:`../../../data-management/streams`.
