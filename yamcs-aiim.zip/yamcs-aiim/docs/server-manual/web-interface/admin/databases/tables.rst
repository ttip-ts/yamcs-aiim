Tables
======

This page lists all the tables in a specific Yamcs database.

For each table we can see a description of its columns, and a sampling of the most recent data rows.

For more information on the standard tables, see :doc:`../../../data-management/archive/index`.
