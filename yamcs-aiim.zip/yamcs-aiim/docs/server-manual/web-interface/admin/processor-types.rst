Processor Types
===============

This page lists the names of preconfigured processors. These correspond with the top-level keys in the :file:`etc/processor.yaml` configuration file.
