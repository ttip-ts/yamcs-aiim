Plugins
=======

This page shows the currently installed Yamcs plugins, and some general metadata.

Yamcs does not enforce a plugin registration mechanism, so the information on this page is dependent on the level of integration of used plugins.
