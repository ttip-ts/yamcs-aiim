Services
========

This page shows available Yamcs services. Services add functionality to Yamcs. Yamcs comes with a default set of services, but may be extended with plugins that deploy other services.

Services participate during start and stop of the Yamcs server.

Services are grouped by instance. A special instance ``_global`` covers global services that are not linked to a specific Yamcs instance.

This page allows to manually start or stop services. This functionality is primarily intended for debugging or development. In normal circumstances services are always up.
