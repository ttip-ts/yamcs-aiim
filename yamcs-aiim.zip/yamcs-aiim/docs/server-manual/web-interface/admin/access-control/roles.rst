Roles
=====

This page provides a readonly view of the configured roles of your Yamcs deployment.

Roles group zero or more privileges.
