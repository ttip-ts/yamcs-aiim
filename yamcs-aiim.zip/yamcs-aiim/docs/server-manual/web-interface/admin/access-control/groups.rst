Groups
======

The groups page allow to group users together. Role assignment is done at either user or group level, and so groups allow to manage role assignment without needing to manage each user individually.
