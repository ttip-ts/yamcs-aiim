Algorithms
==========

The Algorithms page provides access to the algorithms defined for the current Yamcs instance.

Each algorithm can be selected to view general information, input parameters, output parameters, triggers, and edit the algorithm code.