Links
=====

Shows a live view of the data links for this instance. Link can be managed directly from this page.
