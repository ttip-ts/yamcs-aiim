yamcsadmin confcheck
====================

.. program:: yamcsadmin confcheck

Synopsis
--------

.. rst-class:: synopsis
    
    | **yamcsadmin** confcheck


Description
-----------

Check Yamcs configuration.
