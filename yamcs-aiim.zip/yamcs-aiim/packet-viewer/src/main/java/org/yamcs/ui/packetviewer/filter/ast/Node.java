package org.yamcs.ui.packetviewer.filter.ast;

public interface Node {

    String toString(String indent);
}
