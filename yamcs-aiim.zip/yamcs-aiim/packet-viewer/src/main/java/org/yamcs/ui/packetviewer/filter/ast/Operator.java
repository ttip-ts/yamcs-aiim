package org.yamcs.ui.packetviewer.filter.ast;

public enum Operator {
    EQUAL_TO,
    NOT_EQUAL_TO,
    GREATER_THAN,
    GREATER_THAN_OR_EQUAL_TO,
    LESS_THAN,
    LESS_THAN_OR_EQUAL_TO,
    CONTAINS,
    MATCHES;
}
