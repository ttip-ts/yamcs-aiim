curl -XDELETE http://localhost:8090/api/buckets/_global/my_bucket 
