curl -XGET http://localhost:8090/api/buckets/_global/my_bucket?prefix=r
