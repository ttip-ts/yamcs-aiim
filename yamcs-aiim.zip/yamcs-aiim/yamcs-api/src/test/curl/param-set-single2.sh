curl -XPOST http://dcms-v-scs:8090/api/processors/2018-07-18T11h09m04s/realtime/parameters/esim/Big/NodeWithVeryLongNameBlablabla/lotsofenumvariables.c/enum2 -d '{
  "type" : "STRING",
  "stringValue" : "const5"
}'
