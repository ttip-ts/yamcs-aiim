curl -XGET http://localhost:8090/simulator/api/parameter/YSS/SIMULATOR/BatteryVoltage2?pretty
