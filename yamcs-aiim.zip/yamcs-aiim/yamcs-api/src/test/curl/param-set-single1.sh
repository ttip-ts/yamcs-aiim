curl -XPOST http://dcms-v-scs:8090/api/processors/2018-07-18T09h08m05s/realtime/parameters/esim/Big/NodeWithVeryLongNameBlablabla/lotsofvariables.c/int100 -d '{
  "type" : "DOUBLE",
  "doubleValue" : 15.5
}'
