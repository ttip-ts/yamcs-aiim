curl -XPOST http://localhost:8090/api/instances/node2:setTime -d '
  {
    "time0": "2018-04-01T00:00:30Z",
    "elapsedTime": 0,
    "speed": 3
  }'
