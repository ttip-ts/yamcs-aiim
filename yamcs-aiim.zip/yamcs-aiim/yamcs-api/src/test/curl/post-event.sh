curl -XPOST http://localhost:8090/api/archive/simulator/events -d '{"source":"REST API", "type":"Test", "seqNumber":3, "message":"this is a test event", "generationTime":0, "receptionTime":0, "severity":"WARNING"}'
#
