curl "http://localhost:8090/api/archive/simulator/tables/pp/data?cols=/yamcs/nm/tm_dump/linkStatus"
