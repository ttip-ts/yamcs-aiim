curl -XPOST http://localhost:8090/api/buckets/_global -d '{"name": "my_bucket"}' 
