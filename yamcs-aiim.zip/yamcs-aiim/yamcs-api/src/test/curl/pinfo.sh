curl -XGET http://localhost:8090/mwlgt-ops/api/mdb/parameterInfo?pretty -d '
  {
    "list": [
    { "name":"MWL_GT002_HKU_CFG_AIN0_Temp_B ",
    "namespace":"MDB:OPS Name"}
   ]
  }'
